﻿Public Class FmTxtPlayItSam

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As EventArgs) Handles MyBase.Load
        MessageBox.Show(TextBox.FmTxtPlayItSam.Text, "Here your Text Is")
    End Sub
    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged

    End Sub
End Class
